[Document](https://ng-alain.com/mock)
