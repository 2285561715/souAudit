### CoreModule

**应** 仅只留 `providers` 属性。

**作用：**  一些通用服务，例如：用户消息、HTTP数据访问。
